<style>
    .close {
        color: red;
        opacity: 1.3;
        font-size: 30px;
    }

    .p-img {
        height: 80px !important;
        width: 100px !important;
    }
    .form-inline .form-control {
        display: inline-block;
        width: 100%;
        vertical-align: middle;
    }
</style>
<div class="content-wrapper">
    <div class="container">
        <section class="content-header">
            <h1> Products
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active"> Products</li>
            </ol>
        </section>

        <section class="content">
            <?php echo getMessage(); ?>
            <div class="box box-info">
                <div class="box-header with-border">
                    <h3 class="box-title">List Of Products</h3>
                </div>
                <div class="box-body">

                    <table class="table table-bordered data-table table-hover">
                        <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Product Image</th>
                            <th class="w-10">Mfr No</th>
                            <th class="w-15">Product Name</th>
                            <th>Description</th>
                            <th class="w-10">Datasheet</th>
                            <th class="w-10">Pricing(INR)</th>
                            <th class="w-10">Quantity</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if (!empty($products)) {
                            $i = 1;
                            foreach ($products as $product) {
                                if (!empty($product['sub_products'])) {

                                    foreach ($product['sub_products'] as $sub_product) {
                                        if (!empty($sub_product['child_products'])) {

                                            foreach ($sub_product['child_products'] as $child_product) {
                                                if (!empty($child_product['product_details'])) {

                                                    foreach ($child_product['product_details'] as $info) {
                                                        ?>
                                                        <tr>
                                                            <td><?php echo $i; ?></td>
                                                            <td>
                                                                <?php
                                                                $img = !empty($child_product['product_logo']) && file_exists(FCPATH . 'data/child-sub-products/') ? 'data/child-sub-products/' . $child_product['product_logo'] : '';
                                                                ?>
                                                                <img src="<?php echo !empty($img) ? base_url() . $img : dummyLogo() ?>"
                                                                     alt="product image" class="p-img">
                                                            </td>
                                                            <td>123456</td>
                                                            <td ><?php echo $info['child_product_name']; ?></td>
                                                            <td ><?php echo limit_words($info['description_1'],15).'...'; ?></td>
                                                            <td><a href="javascript:void(0)">Datasheet</a> </td>
                                                            <td >
                                                                <input type="text" class="form-control mrp_price" name="mrp_price"  placeholder="Mrp Price" value="<?php echo $info['mrp_price']; ?>" readonly>
                                                            </td>

                                                            <td class="text-center">
                                                                <input type="number" class="form-control quantity text-center" name="quantity"  placeholder="Quantity" min="1" value="1">
                                                                <button data-toggle="modal"  data-target="#view-details" type="submit" data-id="<?php echo $info['product_info_id'] ?>" class="btn btn-sm btn-success buy">Add to Cart</button>
                                                            </td>

                                                        </tr>
                                                        <?php
                                                        $i++;
                                                    }
                                                }
                                                ?>

                                                <?php

                                            }
                                        }

                                    }
                                }

                            }
                        } else {
                            echo "<tr class='text-center text-danger'><td colspan='6'>No Child Sub Product added</td></tr>";
                        } ?>                  </tbody>
                    </table>
                    <div class="text-center">
                        <?php echo !empty($PAGING) ? $PAGING : ""; ?>
                    </div>
                    <div class="modal fade" id="view-details">
                        <div id="product_details"></div>

                        <!-- /.modal-dialog -->
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<script>
    $(document).ready(function () {
        $('body').on('click','.buy',function (e) {
            e.preventDefault();
            var product_info_id = $(this).data('id');
            var quantity = $(this).closest('tr').find('.quantity').val();
            var mrp_price = $(this).closest('tr').find('.mrp_price').val();
            console.log(mrp_price);
            $.ajax({
                type: 'POST',
                url: "<?php echo base_url() ?>" + "owner/add_cart_info/",
                data:{quantity:quantity,product:product_info_id,mrp:mrp_price},
                success: function (data) {
                    $("#product_details").html(data);

                }
            });

        });
    });
</script>