<div class="content-wrapper">
    <div class="container">
        <section class="content-header">
            <h1>Ticket System</h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Ticket System</li>
            </ol>
        </section>
        <section class="content">
            <?php echo getMessage(); ?>
            <div class="box box-info">
                <div class="box-header with-border"><h3 class="box-title">Add Ticket System</h3>
                    <div class="box-tools">
                        <a href="<?php echo base_url(); ?>owner/tickets/" class="btn btn-danger"><i
                                    class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
                <div class="box-body">
                    <form class="form-horizontal" id="frm" method="post" enctype="multipart/form-data">
                        <div class="row">
                            <input type="hidden" name="pk_id"
                                   value="<?php echo !empty($ticket['pk_id']) ? $ticket['pk_id'] : ''; ?>"/>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Ticket Issue Title <sup
                                                class="text-danger">*</sup></label>
                                    <div class="col-md-8">
                                        <input type="text" name="ticket_issue_title" class="form-control" required
                                               placeholder="Ticket Issue Title"
                                               value="<?php echo !empty($ticket['ticket_issue_title']) ? $ticket['ticket_issue_title'] : '' ?>"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4">Priority <sup
                                                class="text-danger">*</sup></label>
                                    <div class="col-md-8">
                                        <select class="form-control" name="priority" required>
                                            <option value="">Select Priority</option>
                                            <option value="High">High</option>
                                            <option value="Medium">Medium</option>
                                            <option value="Medium">Medium</option>
                                            <option value="Low">Low</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4">Select Product <sup
                                                class="text-danger">*</sup></label>
                                    <div class="col-md-8">
                                        <select class="form-control" name="product_name" required>
                                            <option value="">Select Product</option>
                                            <option value="">Product1</option>
                                            <option value="">Product2</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-3">Description</label>
                                    <div class="col-md-9">
                                        <textarea rows="5" class="form-control" name="description"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="box-footer">
                    <div class="pull-right">
                        <a href="<?php echo base_url() ?>owner/tickets/" class="btn btn-danger">Cancel</a>
                        <button form="frm" type="submit" class="btn btn-success">Submit</button>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>

