<div class="content-wrapper">
    <div class="container">
    <section class="content-header">
        <h1>Profile</h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Profile</li>
        </ol>
    </section>
    <section class="content">
        <?php echo getMessage(); ?>
        <div class="box box-info">
            <div class="box-header with-border"><h3 class="box-title">Edit Profile</h3>
            </div>
            <div class="box-body">
                <form class="form-horizontal" id="frm" method="post" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-10">
                            <input type="hidden" name="user_id" value="<?php echo !empty($profile['user_id']) ? $profile['user_id'] : ''; ?>"/>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Account Name </label>
                                    <div class="col-md-8">
                                        <input type="text" name="account_name" class="form-control"  placeholder="Account Name" value="<?php echo !empty($profile['account_name']) ? $profile['account_name'] : '' ?>"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Installation Type <sup class="text-danger">*</sup></label>
                                    <div class="col-md-8">
                                        <input type="text" name="installation_type" class="form-control" required placeholder="Installation Type" value="<?php echo !empty($profile['installation_type']) ? $profile['installation_type'] : '' ?>"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Project Type <sup class="text-danger">*</sup></label>
                                    <div class="col-md-8">
                                        <input type="text" name="project_type" class="form-control" required placeholder="Project Type" value="<?php echo !empty($profile['project_type']) ? $profile['project_type'] : '' ?>"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Date Installed <sup class="text-danger">*</sup></label>
                                    <div class="col-md-8">
                                        <input type="text" name="date_installed" class="form-control" required placeholder="URL" value="<?php echo !empty($profile['date_installed']) ? $profile['date_installed'] : '' ?>"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Dealer Name</label>
                                    <div class="col-md-8">
                                        <input type="text" name="dealer_name" class="form-control" placeholder="Dealer Name" value="<?php echo !empty($profile['dealer_name']) ? $profile['dealer_name'] : '' ?>"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Status</label>
                                    <div class="col-md-8">
                                        <input type="text" name="status" class="form-control" placeholder="Status" value="<?php echo !empty($profile['status']) ? $profile['status'] : '' ?>"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-4">First Name <sup class="text-danger">*</sup></label>
                                    <div class="col-md-8">
                                        <input type="text" name="first_name" class="form-control" required  placeholder="First Name" value="<?php echo !empty($profile['first_name']) ? $profile['first_name'] : '' ?>"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Last Name</label>
                                    <div class="col-md-8">
                                        <input type="text" name="last_name" class="form-control" placeholder="Last Name" value="<?php echo !empty($profile['last_name']) ? $profile['last_name'] : '' ?>"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Company Name</label>
                                    <div class="col-md-8">
                                        <input type="text" name="company_name" class="form-control" placeholder="Company Name" value="<?php echo !empty($profile['company_name']) ? $profile['company_name'] : '' ?>"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Email <sup class="text-danger">*</sup></label>
                                    <div class="col-md-8">
                                        <input type="email" name="email" class="form-control" required placeholder="Email" value="<?php echo !empty($profile['email']) ? $profile['email'] : '' ?>"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Password <sup class="text-danger">*</sup></label>
                                    <div class="col-md-8">
                                        <input type="password" name="password" class="form-control" id="password" required placeholder="Password" value="<?php echo !empty($profile['password']) ? $profile['password'] : '' ?>"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Confirm Password <sup class="text-danger">*</sup></label>
                                    <div class="col-md-8">
                                        <input type="password" name="confirm_password" required class="form-control" placeholder="Confirm Password" value="<?php echo !empty($profile['confirm_password']) ? $profile['confirm_password'] : '' ?>"/>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label"> </label>
                                <div class="col-sm-8">
                                    <input type="checkbox" id="showPassword"/>
                                    <label for="showHide">Show Password</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Phone </label>
                                    <div class="col-md-8">
                                        <input type="text" name="phone_no" class="form-control" placeholder="Phone" value="<?php echo !empty($profile['phone_no']) ? $profile['phone_no'] : '' ?>"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Address</label>
                                    <div class="col-md-8">
                                        <input type="text" name="address" class="form-control"  placeholder="Address" value="<?php echo !empty($profile['address']) ? $profile['address'] : '' ?>"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-4">City <sup class="text-danger">*</sup></label>
                                    <div class="col-md-8">
                                        <input type="text" name="city" class="form-control" required placeholder="City" value="<?php echo !empty($profile['city']) ? $profile['city'] : '' ?>"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-4">State/Province <sup class="text-danger">*</sup></label>
                                    <div class="col-md-8">
                                        <input type="text" name="state" class="form-control" required placeholder="State/Province" value="<?php echo !empty($profile['state']) ? $profile['state'] : '' ?>"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Postal Code <sup class="text-danger">*</sup></label>
                                    <div class="col-md-8">
                                        <input type="text" name="postal_code" class="form-control" required placeholder="Postal Code" value="<?php echo !empty($profile['postal_code']) ? $profile['postal_code'] : '' ?>"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Country <sup class="text-danger">*</sup></label>
                                    <div class="col-md-8">
                                        <select class="form-control" name="country_code" id="country_code" required>
                                            <option value="">Select Country</option>
                                            <?php
                                            if(!empty($countries)){
                                                foreach ($countries as $k=>$v){
                                                    ?>
                                            <option value="<?php echo $k ?>" <?php echo !empty($profile['country_code']) && ($k==$profile['country_code']) ? 'selected=selected' : ''; ?>><?php echo $v; ?></option>
                                            <?php
                                                }
                                            }

                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-4">Time zone  </label>
                                    <div class="col-md-8">
                                        <select class="form-control" name="zone_id" id="zone_id">
                                            <option value="">--Select Zone--</option>
                                            <?php
                                            if(!empty($zones)){
                                                foreach ($zones as $k=>$v){
                                                    ?>
                                                    <option value="<?php echo $k ?>" <?php echo !empty($profile['zone_id']) && ($k==$profile['zone_id']) ? 'selected=selected' : ''; ?>><?php echo $v; ?></option>
                                            <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label col-md-4"> Profile Picture</label>
                                    <div class="col-md-8">
                                        <input type="file" name="user_logo" class="form-control"/>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <h4>Profile Picture</h4>
                            <?php
                            $img = (!empty($profile['user_logo']) && file_exists(FCPATH."data/profile/".$profile['user_logo']))? "data/profile/".$profile['user_logo'] : '';
                            ?>
                            <img src="<?php echo !empty($img) ?base_url(). $img : dummyLogo()  ?>" alt="Profile Pic" class="profile-pic">
                        </div>
                    </div>

                </form>
            </div>
            <div class="box-footer">
                <div class="pull-right">
                    <button form="frm" type="submit" class="btn btn-success">Save</button>
                </div>
            </div>
        </div>
    </section>
    </div>
</div>
<script>
    $('#country_code').on("change", function () {
        var country_code = $(this).val();
        console.log(country_code);
        if ((country_code == "") || (country_code == null)) {
            $('#zone_id').empty();
        }
        else {
            $('#zone_id').empty();
            $.ajax({
                type: 'POST',
                url: "<?php echo base_url() ?>" + "admin/fetch_zones/?country_code=" + country_code,
                dataType: 'json',
                cache: false,
                success: function (data) {
                    $('#zone_id').append($("<option></option>").attr("value", "").text("-- Select a Zone --"));
                    $.each(data, function (key, value) {
                        $('#zone_id').append($("<option></option>").attr("value", key).text(value));
                    });
                }
            });
        }
    });

    $(document).ready(function () {
        $("#showPassword").click(function () {
            if ($("#password").attr("type") == "password") {
                $("#password").attr("type", "text");
            }
            else {
                $("#password").attr("type", "password");
            }
        });
        $("#frm").validate({
            rules: {
                password: {
                    required: true,
                    minlength: 5
                },
                confirm_password: {
                    required: true,
                    minlength: 5,
                    equalTo: "#password"
                }
            },
            messages: {
                password: " Enter Password(minimum 5 characters)",
                confirm_password: " Enter Confirm Password Same as Password"
            }
        });
    });
</script>
