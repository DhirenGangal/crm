<div class="content-wrapper">
    <div class="container">
        <section class="content-header">
            <h1>Purchase Order</h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Purchase Order</li>
            </ol>
        </section>
        <section class="content">
            <?php echo getMessage(); ?>
            <div class="box box-info">
                <div class="box-header with-border">
                    <h3 class="box-title">Purchase Order</h3>
                    <div class="box-tools">
                        <a href="<?php echo base_url(); ?>owner/orders/" class="btn btn-sm btn-danger"><i class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-offset-1 col-md-10">
                            <div class="col-md-6">
                                <?php
                                $img = !empty($site_info['logo']) && file_exists(FCPATH."data/settings") ? "data/settings/".$site_info['logo'] : '';
                                ?>
                                <img src="<?php echo !empty($img) ? base_url().$img : dummyLogo() ?>"/>
                            </div>
                            <div class="col-md-6">
                                <table class="table table-bordered">
                                    <tbody>
                                    <tr>
                                        <th>Order no</th>
                                        <td><?php echo !empty($order['order_no'])? $order['order_no'] : '' ?></td>
                                    </tr>
                                    <tr>
                                        <th>Order Date</th>
                                        <td><?php echo !empty($order['order_date'])? $order['order_date'] : '' ?></td>
                                    </tr>
                                    <tr>
                                        <th>Approved By</th>
                                        <td><?php echo !empty($order['approved_by_name'])? $order['approved_by_name'] : '' ?></td>
                                    </tr>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">
                            <div class="col-md-6">
                                <h4>Order From :</h4>
                                <?php
                                        if(!empty($from_address)){
                                            ?>
                                        <?php echo $from_address['first_name'].' '.$from_address['last_name'] ; ?>
                                        <?php echo $from_address['address'] ; ?>
                                        <?php echo " <b>Email </b> : " .$from_address['email'] ; ?><br/>
                                        <?php echo !empty($from_address['phone_no']) ? " <b>Phone No </b> : " . $from_address['phone_no'] : '' ; ?>

                                        <?php
                                        }
                                        ?>

                            </div>
                            <div class="col-md-6">
                                <h4>Order To :</h4>
                                <?php
                                if(!empty($to_address)){
                                    ?>
                                    <?php echo $to_address['first_name'].' '.$to_address['last_name'] ; ?><br/>
                                    <?php echo $to_address['address'] ; ?><br/>
                                    <?php echo $to_address['city'] ; ?><br/>
                                    <?php echo $to_address['state'] ; ?><br/>
                                    <?php echo $to_address['postal_code'] ; ?><br/>
                                    <?php echo " <b>Email </b> : " .$to_address['email'] ; ?><br/>
                                    <?php echo !empty($to_address['phone_no']) ? " <b>Phone No </b> : " . $to_address['phone_no'] : '' ; ?><br/>

                                    <?php
                                }
                                ?>

                            </div>
                        </div>

                    </div>
                    <div class="col-md-12">
                    <table class="table table-bordered product_table" id="dynamic_field">
                        <thead>
                        <tr>
                            <td>S.No</td>
                            <th>Main Product</th>
                            <th>Sub product</th>
                            <th>Child Product</th>
                            <th>Unit Price</th>
                            <th>Quautity</th>
                            <th>Discount (%)</th>
                            <th>Total Price</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        if(!empty($order['order_items'])){
                            foreach ($order['order_items'] as $order_item){
                                ?>

                                <tr>
                                    <td>1</td>
                                    <td><?php echo !empty($order_item['main_product'])? $order_item['main_product'] : '' ?></td>
                                    <td><?php echo !empty($order_item['sub_product'])? $order_item['sub_product'] : '' ?></td>
                                    <td><?php echo !empty($order_item['child_product'])? $order_item['child_product'] : '' ?></td>
                                    <td><?php echo !empty($order_item['unit_price'])? $order_item['unit_price'] : '' ?></td>
                                    <td><?php echo !empty($order_item['quantity'])? $order_item['quantity'] : '' ?></td>
                                    <td><?php echo !empty($order_item['discount_amount'])? $order_item['discount_amount'] : '' ?></td>
                                    <td><?php echo !empty($order_item['total_amount'])? $order_item['total_amount'] : '' ?></td>
                                    <td class="hide">
                                        <button type="button" class="btn btn-sm btn-success add" id="add"><i
                                                    class="fa fa-plus"></i></button>
                                    </td>
                                </tr>
                        <?php
                            }
                        }
                        ?>

                        </tbody>
                        <tfoot>
                        <tr class="text-center"><td colspan="7">PLEASE NOTIFY US IMMEDIATELY IF THIS ORDER CANNOT BE SHIPPED COMPLETE ON OR BEFORE: <?php echo dateDB2SHOW($order['expected_date']) ?></td></tr>
                        </tfoot>
                    </table>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label>Remarks</label>
                                    <textarea class="form-control" name="remarks" rows="6"
                                              placeholder="Enter remarks"><?php echo !empty($order['remarks'])? $order['remarks'] : '' ?></textarea>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <h4 class="text-center"><b>Payment Information</b></h4>
                                <table class="table table-bordered">
                                    <tbody>
                                    <tr>
                                        <th class="w-50"> TOTAL AMOUNT</th>
                                        <td>
                                            <span><i class="fa fa-inr"></i> <span class="total"><?php echo !empty($order['sub_amount']) ? $order['sub_amount'] : 0.00; ?></span></span>
                                            <input type="hidden" name="sub_amount" class="input_total" value="<?php echo !empty($order['sub_amount']) ? $order['sub_amount'] : 0; ?>"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="w-50">DISCOUNT TOTAL</th>
                                        <td>
                                            <span><i class="fa fa-inr"></i> <span class="discount_total"><?php echo !empty($order['discount_total']) ? $order['discount_total'] : 0.00; ?></span> </span>
                                            <input type="hidden" name="discount_total" class="input_discount_total" value="<?php echo !empty($order['discount_total']) ? $order['discount_total'] : 0.00; ?>"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="w-50">FINAL TOTAL</th>
                                        <td>
                                            <span><i class="fa fa-inr"></i> <span class="final_total"><?php echo !empty($order['final_total']) ? $order['final_total'] : 0.00; ?></span> </span>
                                            <input type="hidden" name="final_total" class="input_final_total" value="<?php echo !empty($order['final_total']) ? $order['final_total'] : 0.00; ?>"/>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
